package com.dostel.managerapp1;

public class RoomListItem {

    private String roomNo;

    public RoomListItem(String roomNo) {
        this.roomNo = roomNo;
    }

    public String getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(String roomNo) {
        this.roomNo = roomNo;
    }
}
